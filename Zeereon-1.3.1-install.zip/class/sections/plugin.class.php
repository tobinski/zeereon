<?php


class etempus_plugin extends etempus {

		public $layout=true;
		
		
		public function index(){
		}		

}


?>
