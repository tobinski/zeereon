<?php

include ("inc.php");
include ("class/datacenter.class.php");
$et=new etempus_datacenter;
$et->build();

?>
