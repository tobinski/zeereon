<?php
/**************************************************
 * 
 * eTempus setup-konfiguration
 * (c) 2009 cyrill v.wattenwyl, protagonist gmbh
 * 
 * ************************************************/

// setup-ordner nach installation löschen
define("ET_SETUP_DEL_FOLDER",	false);

// setup-ordner
define("ET_SETUP_FOLDER",		"setup/");

// datenbankdatei name
define("ET_SETUP_SQLITE_FILE",	"etempus.sdb");

// ftp-chmod-mode
define("ET_SETUP_FTP_CHMODE",	"0777");
?>
