<?php

$txt['etempus_setup']		= "eTempus Setup";
$txt['schritt']				= "Step";
$txt['s_einfuehrung']		= "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras nulla enim, volutpat eu consectetur sed, dignissim vestibulum lacus. Duis dignissim blandit quam, eget facilisis elit molestie in. Ut eu accumsan purus. Curabitur bibendum mauris imperdiet dui lacinia accumsan. Curabitur facilisis placerat dolor sed semper. Sed pretium posuere neque et congue. Aliquam erat volutpat. Morbi at dolor sem, et elementum nibh. Ut nisl nulla, porttitor vitae tempor ac, cursus quis felis. Vivamus viverra libero vitae urna laoreet a eleifend diam blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eu ipsum vitae sapien interdum dictum. Phasellus accumsan justo ac sapien luctus faucibus. Curabitur tincidunt facilisis nisl, sit amet blandit libero imperdiet nec. Quisque tempor leo ut tortor sodales eget feugiat orci cursus. Etiam convallis tincidunt mollis. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Praesent dolor nisl, viverra et porttitor a, congue ut est. Vestibulum vitae massa sit amet enim lobortis sollicitudin in id lorem. Vivamus sapien leo, rhoncus sit amet rhoncus vitae, sodales sed libero.

Duis lacinia magna commodo felis consectetur ut aliquam urna bibendum. Suspendisse potenti. Etiam nec elit at leo placerat semper eget a felis. Donec libero dolor, tempor non cursus iaculis, congue vel justo. Pellentesque lacinia leo sed risus tristique quis varius arcu sodales. Vestibulum at ligula et velit ultrices cursus. In imperdiet augue tincidunt enim blandit tempor. Duis leo purus, lobortis sit amet eleifend at, lacinia at leo. Pellentesque id nunc purus, id porttitor mauris. Aliquam erat volutpat. Nam vestibulum lacinia ligula, id posuere ipsum tincidunt id. Suspendisse potenti. Cras vel nibh et diam dictum varius. Integer et tempor est. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; ";
$txt['']		= "";



?>
