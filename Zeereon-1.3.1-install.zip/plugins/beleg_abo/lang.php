<?php

$de['einleitung']		=	"Damit die Abos richtig gebucht werden muss diese Seite entweder t&auml;glich aufgerufen werden, <br />
							 oder die Updater-Url in einen Cronjob-Service eingetragen werden. Die Updater-Url ben&ouml;tigt kein Benutzername/Passwort !";
$de['abo']				=	"Beleg-Abos";
$de['db_err']			=	"Datenbank-Error";
$de['abo_db_created']	=	"Erster Aufruf von Plugin. Die Tabelle <b>abo_belege</b> wurde erfolgreich erstellt.";
$de['neues_abo']		=	"neues Abo erstellen";
$de['updater_url']		=	"Updater-Url";
$de['show_updater_url']	=	"Updater-Url anzeigen";
$de['wiederhole']		=	"Zyklus";
$de['woechentlich']		=	"w&ouml;chentlich";
$de['monatlich']		=	"monatlich";
$de['jaehrlich']		=	"j&auml;hrlich";
$de['alle']				=	"alle";
$de['tage']				=	"Tage";
$de['no_ts_selected']	=	"Kein g&uuml;ltiger Zeitraum ausgew&auml;hlt";
$de['erste_buchung']	=	"Erste Buchung";
$de['jetzt_buchen']		=	"Jetzt";
$de['buche_spaeter']	=	"Nach dem oben ausgew&auml;hlten Zeitraum";
$de['abo_erstellt']		=	"Neues Abo erfolgreich erstellt";
$de['abo_geloescht']	=	"Abo gel&ouml;scht";
$de['vorhandene_abos']	=	"vorhandene Abos";
$de['last']				=	"letzte Buchung";
$de['abo_loeschen']		=	"dieses Abo l&ouml;schen";
$de['abo_entry_update']	=	"Es wurden Abos gebucht. Die gebuchten Abos sind rot unterlegt.";
$de['button_ok']		=	"ok";


$en['einleitung'] 		= 	"In order that subscriptions are properly booked this page must be called either daily, <br />
						   	 or be the Updater-Url has to be registred in a cronjob service. The Updater Url does not require a username / password! ";
$en['abo'] 				=	"Proof subscriptions";
$en['db_err'] 			= 	"Database Error";
$en['abo_db_created'] 	= 	"First use of plugin. The table <b>abo_belege</b> was successfully created.";
$en['neues_abo'] 		= 	"Create new subscription";
$en['updater_url'] 		= 	"Updater-Url";
$en['show_updater_url'] = 	"Show Updater-Url";
$en['wiederhole'] 		= 	"cycle";
$en['woechentlich']		=	"weekly";
$en['monatlich'] 		= 	"monthly";
$en['jaehrlich'] 		= 	"year";
$en['alle']				= 	"every";
$en['tage'] 			= 	"Days";
$en['no_ts_selected'] 	= 	"No valid period selected";
$en['erste_buchung'] 	= 	"First Book";
$en['jetzt_buchen'] 	= 	"Now";
$en['buche_spaeter'] 	=	"After the period selected above";
$en['abo_erstellt'] 	= 	"New subscription was created successfully";
$en['abo_geloescht'] 	= 	"Subscription deleted";
$en['vorhandene_abos'] 	=	"Existing subscriptions";
$en['last'] 			= 	"last book";
$en['abo_loeschen'] 	= 	"Delete this plan";
$en['abo_entry_update'] = 	"Some subscriptions are have been booked. Booked subscriptions are marked red.";
$en['button_ok'] 		= 	"ok";


?>
